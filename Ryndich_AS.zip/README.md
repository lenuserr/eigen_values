Third task from Bogachev. Mechmat, 3rd year, winter, 2023 
